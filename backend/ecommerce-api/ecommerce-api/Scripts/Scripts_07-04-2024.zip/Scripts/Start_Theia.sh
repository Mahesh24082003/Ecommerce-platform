#!/usr/bin/env bash

#/usr/bin/yarn browser start /TekstacLabRoot --hostname 0.0.0.0 --port 3000  >> /var/log/SupervisorD/Start_Theia/Start_Theia.out.log 2>> /var/log/SupervisorD/Start_Theia/Start_Theia.err.log & 
UserName="tekuser"
Log_DIR="/var/log/TekStac/Start_Theia"
#if ! [[ -d ${Log_DIR} ]]
#then
#	mkdir -p ${Log_DIR}
#fi
#chown -R ${UserName} ${Log_DIR}

#TekStacDirectory=/TekstacLabRoot
#chmod -R 777 ${TekStacDirectory}

#hmod -R 777 /tmp


TheiaDirectory=/tekstac
#chmod -R 777 ${TheiaDirectory}

Log_File="${Log_DIR}/Start_Theia.out.log"
#runuser -l ${UserName} -c "/usr/bin/yarn --cwd /theia browser start /home/theiauser/TekstacLabRoot --root-dir /theia --hostname 0.0.0.0 --port 3000  >> ${Log_File} & 2>> ${Log_File}" 

#runuser -l ${UserName} -c "/usr/bin/yarn --cwd /tekstac browser start --hostname 0.0.0.0 --port 3000  >> ${Log_File} & 2>> ${Log_File}"
/usr/local/bin/yarn --cwd /tekstac browser start --hostname 0.0.0.0 --port 3000  >> ${Log_File} & 2>> ${Log_File}

#/usr/bin/yarn --cwd /theia browser start --hostname 0.0.0.0 --port 3000  >> ${Log_File} & 2>> ${Log_File}
