export "HTTP_PROXY=http://172.31.9.183:3128"
export "HTTPS_PROXY=http://172.31.9.183:3128"
export "NO_PROXY=localhost,127.0.0.1"
